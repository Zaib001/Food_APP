import React, { useState } from 'react';
import Select from 'react-select';
import {
  FaCalendarAlt,
  FaMapMarkerAlt,
  FaUtensils,
  FaSave
} from 'react-icons/fa';
import { useRecipes } from '../../contexts/RecipeContext';

export default function MenuPlanner({ onSubmit }) {
  const { recipes } = useRecipes();

  const [menu, setMenu] = useState({
    date: '',
    base: '',
    breakfast: [],
    lunch: [],
    dinner: [],
  });

  const handleChange = (field, value) => {
    setMenu(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...menu,
      breakfast: menu.breakfast.map(r => r.value),
      lunch: menu.lunch.map(r => r.value),
      dinner: menu.dinner.map(r => r.value),
    });
    setMenu({
      date: '',
      base: '',
      breakfast: [],
      lunch: [],
      dinner: [],
    });
  };

  const recipeOptions = (mealType) =>
    recipes
      .filter(r => r.type?.toLowerCase() === mealType)
      .map(r => ({ value: r.id, label: r.name }));

  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-xl shadow mb-6">
      <div className="flex items-center gap-2 mb-4 text-gray-800">
        <FaUtensils className="text-red-600" />
        <h2 className="text-xl font-bold">Plan New Menu</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div>
          <label className="text-sm block mb-1 flex items-center gap-1">
            <FaCalendarAlt /> Date
          </label>
          <input
            type="date"
            value={menu.date}
            onChange={(e) => handleChange('date', e.target.value)}
            className="w-full px-3 py-2 border rounded"
            required
          />
        </div>

        <div>
          <label className="text-sm block mb-1 flex items-center gap-1">
            <FaMapMarkerAlt /> Base / Location
          </label>
          <input
            type="text"
            value={menu.base}
            onChange={(e) => handleChange('base', e.target.value)}
            className="w-full px-3 py-2 border rounded"
            placeholder="e.g. Camp Alpha"
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div>
          <label className="text-sm block mb-1">Breakfast Recipes</label>
          <Select
            isMulti
            options={recipeOptions('breakfast')}
            value={menu.breakfast}
            onChange={(val) => handleChange('breakfast', val)}
            placeholder="Select breakfast recipes"
          />
        </div>
        <div>
          <label className="text-sm block mb-1">Lunch Recipes</label>
          <Select
            isMulti
            options={recipeOptions('lunch')}
            value={menu.lunch}
            onChange={(val) => handleChange('lunch', val)}
            placeholder="Select lunch recipes"
          />
        </div>
        <div>
          <label className="text-sm block mb-1">Dinner Recipes</label>
          <Select
            isMulti
            options={recipeOptions('dinner')}
            value={menu.dinner}
            onChange={(val) => handleChange('dinner', val)}
            placeholder="Select dinner recipes"
          />
        </div>
      </div>

      <div className="text-right mt-4">
        <button
          type="submit"
          className="bg-red-600 text-white px-6 py-2 rounded hover:bg-red-700 flex items-center gap-2"
        >
          <FaSave /> Save Menu
        </button>
      </div>
    </form>
  );
}
